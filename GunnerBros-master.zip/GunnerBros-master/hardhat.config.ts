import "./hardhat.tasks";
import conf from "./hardhat.export";

export default conf;
